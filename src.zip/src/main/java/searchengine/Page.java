package searchengine;

public class Page {




}
