package searchengine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryHandler {

  
    
    public QueryHandler(){
      
        
    }
    
  /**Creates a local Arraylist of lists of type string.
   * Loops trough pages<> and adds page to result<> if 
   * page contains searchTerm and return result<>.
  */
  //This method is not used, after invertedIndex is used
  public List<List<String>> search(String searchTerm, List<List<String>> pages) {
    var result = new ArrayList<List<String>>();
    for (var page : pages) {
      if (page.contains(searchTerm)) {
        result.add(page);
      }
    }
    return result;
  }



}
