package searchengine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InvertedIndex {
   List<List<String>> pages;
   Map<String, ArrayList<String>> hashMap;
   ArrayList<Integer> integerList;


    public InvertedIndex(List<List<String>> pages){
        this.pages = pages;
        hashMap = new HashMap<String, ArrayList<String>>();

    }

    public void createIndex(){
        int pageIndex = 0;
        int lineIndex = 0;
        String formattedUrl = "";

        for (List<String> page : pages) {
            for (String string : page) {
                if (lineIndex == 0) {
                    formattedUrl = String.format("{\"url\": \"%s\", \"title\": \"%s\"}",
                    page.get(0).substring(6), page.get(1));
                    //possible to format and store url here, if needed
                    lineIndex++;

                }else if (!hashMap.containsKey(string)){ //if key does not exist in map
                    hashMap.put(string, new ArrayList<String>());
                    hashMap.get(string).add(formattedUrl);
                    lineIndex++;
                }   
                    else{ //if key already exists in map
                        if (!hashMap.get(string).contains(formattedUrl)){
                        hashMap.get(string).add(formattedUrl);
                        }
                    lineIndex++;
                }
            }
            lineIndex = 0;
            pageIndex++;
        
    }
}

}
